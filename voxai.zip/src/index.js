import React from 'react';
import ReactDOM from 'react-dom/client';
import VoxAI from './VoxAI';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <VoxAI />
  </React.StrictMode>
);
